
Tutorial / How to use
=====================

The tutorial can be found
`here <http://nbviewer.jupyter.org/github/vrodgom/statmorph/blob/master/notebooks/tutorial.ipynb>`_.
