
API Reference
=============

.. autoclass:: statmorph.SourceMorphology
   :members:

.. autofunction:: statmorph.source_morphology
