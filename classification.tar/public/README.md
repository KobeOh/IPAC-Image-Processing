python train.py --help
