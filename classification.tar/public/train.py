"""
Written by Willaim Wei
Last Edit: Jun 12, 2019

Train the model
"""

import argparse
import logging

from tqdm import trange

import numpy as np
import os, sys
from h5py import File
import copy
import glob
import string, random

import utils
import net


import torch
import torch.nn as nn
from torchvision import models

parser = argparse.ArgumentParser()
parser.add_argument('--train_dir', default='./data', help="Directory for the training set")
parser.add_argument('--test_dir', default='./data', help="Directory for the training set")
parser.add_argument('--checkpoint_dir', default='./checkpoints', help="Directory for the training set")
parser.add_argument('--log_dir', default='./logs', help="Directory for log files")
parser.add_argument('--batch_size',action='store', type=int, default=32, help="Batch size")
parser.add_argument('--learning_rate',action='store', type=float, default=1.0e-4, help="Learning rate")
parser.add_argument('--num_batches',action='store', type=float, default=5000, help="Number of batches to be iterated in the training process")
parser.add_argument('--gpu',action='store_true', help="GPU available")


def train_and_evaluate(model1, model2, model3, criterion, optimizer, num_batches):
    """ Main loop for the training process

    Args:
        model1: part 1 of the model
        model2: part 2 of the model
        model3: part 3 of the model
        criterion: loss function
        optimizer: optimizer
        num_batches: the number of batches to be iterated
    """

    logging.info("Preparing datasets...")
    q_train, q_test = utils.data_loader(args.batch_size, args.train_dir, args.test_dir)
    logging.info("- done.")

    random_name = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(16)])
    best_loss = 10.

    t = trange(num_batches)
    for e in t:
        # Training
        model1.train()
        model2.train()
        model3.train()

        pair = q_train.get()

        in_batch = torch.tensor(pair[0], requires_grad = True)
        padding_batch = torch.zeros((args.batch_size,1,299,299))
        target_batch = torch.tensor(pair[1])

        if args.gpu:
            in_batch = in_batch.cuda()
            target_batch = target_batch.cuda()
            padding_batch = padding_batch.cuda()

        optimizer.zero_grad()

        out_batch = model3(torch.cat((model1(in_batch[:,:3,:,:]), model2( torch.cat((in_batch[:,3:5,:,:], padding_batch), dim=1) )), dim=1))

        loss = criterion(out_batch, target_batch)
        loss.backward()
        optimizer.step()

        pred_batch = torch.argmax(out_batch.detach(), dim=1)
        accuracy = torch.sum(pred_batch.cpu()==target_batch.cpu()).item()/args.batch_size

        # Testing
        with torch.no_grad():
            model1.eval()
            model2.eval()
            model3.eval()

            test_pair = q_test.get()

            test_in_batch = torch.tensor(test_pair[0])
            test_padding_batch = torch.zeros((args.batch_size,1,299,299))
            test_target_batch = torch.tensor(pair[1])

            if args.gpu:
                test_in_batch = test_in_batch.cuda()
                test_target_batch = test_target_batch.cuda()
                test_padding_batch = test_padding_batch.cuda()

            test_out_batch = model3(torch.cat((model1(test_in_batch[:,:3,:,:]), model2( torch.cat((test_in_batch[:,3:5,:,:], test_padding_batch), dim=1) )), dim=1))
            test_loss = criterion(test_out_batch, test_target_batch)
            
            test_pred_batch = torch.argmax(test_out_batch, dim=1)
            test_accuracy = torch.sum(test_pred_batch.cpu()==test_target_batch.cpu()).item()/args.batch_size
            
            t.set_postfix(test_accuracy='{:04.2f}'.format(test_accuracy))

            with open(args.log_dir + '/resnet_loss_'+random_name+'.out', 'a+') as out_stream:
                out_stream.write(str((e, loss.item(), test_loss.item(), accuracy, test_accuracy))+'\n')
                out_stream.flush()

            # Save the best models
            if test_loss < best_loss:
                utils.save_checkpoint(model1.state_dict(), model2.state_dict(), model3.state_dict(), optimizer.state_dict(), args.checkpoint_dir, 'best_'+random_name)
            # Save the models every 128 iteration
            if e%128 == 127:
                utils.save_checkpoint(model1.state_dict(), model2.state_dict(), model3.state_dict(), optimizer.state_dict(), args.checkpoint_dir, random_name)


if __name__ == '__main__':
    args = parser.parse_args()

    np.random.seed(0)
    torch.manual_seed(0)
    random.seed(0)

    if not os.path.exists(args.log_dir):
        print("Making log directory {}".format(args.log_dir))
        os.mkdir(args.log_dir)
        print("- done.")

    utils.set_logger(os.path.join(args.log_dir, 'train.log'))


    logging.info("Loading pre-trained models...")
    # Load pre-trained models
    model1 = models.resnet18(pretrained=True)
    model2 = models.resnet18(pretrained=True)
    model3 = net.Merge()
    logging.info("- done.")

    model1.fc = nn.Linear(512, 1000)
    model2.fc = nn.Linear(512, 1000)

    # Use GPU(s) if possible
    if args.gpu:
        model1.cuda()
        model2.cuda()
        model3.cuda()


    # Set up the loss function and the optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(list(model1.parameters())+list(model2.parameters())+list(model3.parameters()), lr=1.0e-4)

    # Main function for the training and evaluating
    train_and_evaluate(model1, model2, model3, criterion, optimizer, args.num_batches)

