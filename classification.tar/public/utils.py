"""
Written by Willaim Wei
Last Edit: Jun 12, 2019

Auxiliary functions
"""

import logging
import os

import numpy as np
import glob
from h5py import File

import torch

import skimage.transform as transform
from scipy.ndimage import rotate
from skimage.transform import resize

def worker(q, batch_size, path):
    """ Load and pre-process images in batches

    Args:
        q: queue used to store batches of images
        batch_size: batch size
        path: path to images
    """
    files = sorted(glob.glob(path))
    class_index = None
    for i in range(10000):
        tmp = np.zeros((batch_size, 5, 299, 299), dtype = np.float32)
        target = np.zeros((batch_size), dtype = np.int64)
        for i in range(batch_size):
            class_index = np.random.randint(4)
            f = File(files[class_index],'r')
            image_index = np.random.randint(f['im'].shape[0])
            angle = np.random.uniform(0.,360.)
            flip = np.random.randint(2)
            for j in range(5):
                if flip:
                    tmp[i,j,:,:] = transform.rotate(np.flipud(resize(f['im'][image_index][j][124:174,124:174], (299, 299))), angle)
                else:
                    tmp[i,j,:,:] = transform.rotate(resize(f['im'][image_index][j][124:174,124:174], (299, 299)), angle)

                if np.amax(np.absolute(tmp[i,j,:,:])):
                    tmp[i,j,:,:] = tmp[i,j,:,:] / np.amax(np.absolute(tmp[i,j,:,:]))

            target[i] = class_index
            f.close()
        q.put([tmp, target])

def data_loader(batch_size, train_data_path, test_data_path):
    """ Start new processes to load datasets.
    
    Args:
        batch_size: batch size for the model
        train_data_path: path to the training set
        test_data_path: path to the test set
    """


    q_train = torch.multiprocessing.Queue(maxsize=100)
    q_test = torch.multiprocessing.Queue(maxsize=100)
    
    p_train = torch.multiprocessing.Process(target=worker, args=(q_train, batch_size, train_data_path))
    p_train.start()
    p_test = torch.multiprocessing.Process(target=worker, args=(q_test, batch_size, test_data_path))
    p_test.start()

    return q_train, q_test


def set_logger(path):
    """Show the log info in terminal and save to `path`.

    Args:
        path: directory for the log files
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        # Logging to a file
        file_handler = logging.FileHandler(path)
        file_handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s: %(message)s'))
        logger.addHandler(file_handler)

        # Logging to console
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(logging.Formatter('%(message)s'))
        logger.addHandler(stream_handler)

def save_checkpoint(dict1, dict2, dict3, dict4, path, name):
    """ Save the models to the specified files

    Args:
        dict1: parameters for model 1
        dict2: parameters for model 2
        dict3: parameters for model 3
        dict4: parameters for model 4
        path : path to the checkpoint directory
        name: unique name for each trial
    """
    if not os.path.exists(path):
        print("Making checkpoint directory {}".format(path))
        os.mkdir(path)
        print("- done.")

    torch.save(dict1, path + '/model_1_' + name + '.pth')
    torch.save(dict2, path + '/model_2_' + name + '.pth')
    torch.save(dict3, path + '/model_3_' + name + '.pth')
    torch.save(dict4, path + '/optim_' + name + '.opt')
