"""
Written by Willaim Wei
Last Edit: Jun 12, 2019

Neural network architecture(s)
"""

import torch.nn as nn


class Merge(nn.Module):
    def __init__(self):
        super(Merge, self).__init__()
        self.linear = nn.Linear(2000,4)

    def forward(self, x):
        x = self.linear(x)

        return x

